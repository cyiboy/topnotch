

var firebaseConfig = {
    apiKey: "AIzaSyBaCJK30hGFWu-hcKLmZFcRWozcow1ty1o",
    authDomain: "topnotch-99f79.firebaseapp.com",
    databaseURL: "https://topnotch-99f79.firebaseio.com",
    projectId: "topnotch-99f79",
    storageBucket: "topnotch-99f79.appspot.com",
    messagingSenderId: "602021827706",
    appId: "1:602021827706:web:a975bada5e4e4116dd17c3",
    measurementId: "G-BETX37Q1D1"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
  var db = firebase.firestore();
 // var storage = firebase.storage();
 // var storageRef = storage.ref();


// index page 
// contest reqigation
//var mountainsRef = storageRef.child('..//assets/img/twitter.png');
       